# list.py
# in-text examples

items = [10, 3, -1, 8, 24]
print(items[1])
print(items[-1])
print(items[2:4])

print()

items = [-2, 5, 3, -8, 7]
items[0] = 10
print(items)
items = [-2, 5, 3, -8, 7]
items[1:3] = [0]
print(items)
