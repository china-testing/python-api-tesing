result = 0
for i in range(4):
    result += 1
    print(i, result)
