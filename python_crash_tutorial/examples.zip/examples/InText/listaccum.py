result = []
for i in range(4):
    result += [i**2]
    print(i, result)
