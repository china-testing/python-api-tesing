# loop.py
# A subtle accumulation loop.

def main():
    x = 0
    while x != 1:
        print(x)
        x += 0.1

main()
