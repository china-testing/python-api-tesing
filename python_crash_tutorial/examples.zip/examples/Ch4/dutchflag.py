# dutchflag.py

from PIL import Image

def dutchflag(width, height):
    """Return new image of Dutch flag."""
    img = Image.new("RGB", (width, height))
    for j in range(height):
        for i in range(width):
            if j < height/3:
                img.putpixel((i, j), (174, 28, 40))
            elif j < 2*height/3:
                img.putpixel((i, j), (255, 255, 255))
            else:
                img.putpixel((i, j), (33, 70, 139))
    return img

def main():
    img = dutchflag(600, 400)
    img.save("dutchflag.jpg")
    
main()
